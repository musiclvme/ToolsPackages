------------------------------------------------------------------------
-ettsi-rir.em- R aemd eifelf rot eht se tifel sof rht eII Riftlrem dolu
e------------------------------------------------------------------------
-D
sercpiitnoo  fifel:s~
~~~~~~~~~~~~~~~~~~~~t
se-tii.rmr:eT	ih sifelt
se-tii.riz:pZ	PIc-moapitlb erahcvi eiwhtt eht se tifel snit ehU in x	
b	ty eroeitntaoi nh(gi-hybetf rits
)ettsi-ris.at	:SAIC Iifelw ti htstasiitscf rot ehf liseb lewo
.accs7g21r.fe :  II Raccsda-eofmrG 7.21 ,:1,1s =fk8zH[ egenaret dybc 17d2me]oi
rii-srr.fe :  I RIc saacedf-ro mRI,S1 1: ,fs8=Hk zg[neretadeb  yridsme]ot
se.trs:cG	uassai nspueodn-ioest se tifel
.ettscp1mr.fe	:II RCPDMME Oaparlllef-ro m.G17 2:1,1f ritss atego  fcpdmme ot
septmc.der:fI	RIP MCEDOMp ralael-lofmrG 7.212 1: ,ifsr ttsga efop mcedom
 ettscpumr.fe	:II RCPDMME Oaparlllef-ro m.G17 2:1,2f ritss atego  fcpdmme
oN
tose
:~~~~~~-
p mcedomd eo son tmilpmene tht eII RRI Siftlre ,entieh rht eaccsda-eofmr
   .G17.2I  tah sebnek pe tufcnitnolayli edtncilat  oht eTS9L 2cpdmme.o
c  -
f liset septmc.1er,ft septmc.der,fa dnt septmc.uer fra esude 
t  oettsb to hcpdmme.oF li eii-rri.ser fsiu es dott se tnoyli sredom ,na d 
f li eaccs7g21r.fei  snoylu es dott se t7c21edomc.
.-
a tumotacit se trpcoderu era evaiaallb enit ehm kafelise
:m	ka-emv.soc m -of rAV/XMV SaV-xccc moipel rrot ehV SMp ro tfog cc	
amekifelb.cc- f roM DSSOB roaldnb cc	
amekifeld.cj- f roM DSSOp ro tfog cc	
amekifelu.xn- f roU in,xu isgne tieh rcc ,ca cS(nu,)o  rcg
c-
a llt ehb nira yifel sra enit ehS nuf roam tH(gi-hybetf rits,)a dnt  oeb 
u es dniV SMa dnM DSSOn ee doth va evere yvenea dno ddb tyses awppde
.-
t eht septmc.?er fifel sahevb ee negenaret drfmot se.trs cof rht eerefercn
e  milpmeneatitnoo  fht erpgoarsmc moipel dybS nus'c  cocpmlire .iFel s 
c sagc17.2er fna dii-rri.ser fewerg neretadeo  n aPHw roskatitnou isgng cc
.  oY uam yxeeptct ah turnnni ght erpgoar mnio htrep alftrosmm yag nereta e 
f liset ah tra eon tdineitac,lb tut ah tam yahevs mo eidffrene taspmel,s
   ud eotr uodnni greorsr .hTrefero,ee pxce treorsri  nht eargn efo+ 1-
   hwnec moapirgnt ehr fereneecf lisea dny uo rrpcosees dnose
.-
 -s<mioac@dtc.moas.toc>m- 
-